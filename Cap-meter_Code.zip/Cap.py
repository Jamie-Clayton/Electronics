# File:     Cap.py
# Author:   Garth Niethe
# Date:     19-10-2020
# Brief:    Calculate the size of capacitor based on RC network
#             connected to GPIO pins 2 and 3
#
#       GPIO2   ---------                 +3.3V-------
#               |       |                   |        |
#          10k  >       > 10k           --------     > 10k
#               >       >               | LM393 |    >
#               |       |_______________| _     |    |
#               |-------|---------------| +     |____|  GPIO3
#               |       |               |       |
#          C?  ---      > 20k           |       |
#              ---      >               |_______|
#               |_______|___________________|
#                               |
#                              GND

import RPi.GPIO as gpio
import time

# Ignore GPIO warnings
gpio.setwarnings(False)

# Initialise GPIO pins we will use
gpio.setmode(gpio.BCM)
gpio.setup(2, gpio.OUT)
gpio.setup(3, gpio.IN, pull_up_down=gpio.PUD_DOWN)

# Initialise our variables
t_sec = 0
Cap = 0
Res = 10000

print("Initialising ...")
# Send GPIO2 low first to ensre capacitor is fully discharged 
gpio.output(2, gpio.LOW)
time.sleep(3)

print ("Calculating capacitor  size ...")

# Start charging capacitor
gpio.output(2, gpio.HIGH)

# Comparator should go high when capacitor voltage is greater than 2/3
# of GPIO voltage
while gpio.input(3) != True:
    time.sleep(0.001)       # this is about the minimum sleep time the Raspberry Pi can do
    t_sec = t_sec + 0.001

# Calculate capacitance based on Tau = R x C
Cap = t_sec / Res

print("Completed in", t_sec, "seconds")

print("Your capacitor is", Cap, "Farads")
